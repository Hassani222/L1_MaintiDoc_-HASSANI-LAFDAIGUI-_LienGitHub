# Prompts utilisés pour constituer le corpus — MaintiDoc

Outil : **Claude (Anthropic)** — conversation du 2026-10-31. Domaine choisi : automobile.
Familles d'équipements : (1) système de freinage (disques, plaquettes, étriers, ABS, maître-cylindre) ; (2) équipements d'entretien moteur (filtres, bougies, courroie, huile moteur, circuit de refroidissement).
Voie utilisée : **génération de documents synthétiques** (véhicule fictif « Zephyr 1.6 T », parc FLOTTE-07 et FLOTTE-09). Aucun document public n'a été téléchargé.

## P01 — 2026-10-31 — Claude
> « Donne-moi un corpus dans le domaine automobile pour deux familles d'équipements : système de freinage (disques, plaquettes, étriers, ABS, maître-cylindre) et entretien moteur (filtres, bougies, courroie, huile moteur, circuit de refroidissement). »

## P02 — 2026-10-31 — Claude
> « Juste 3 PDF. »

## P03 — 2026-10-31 — Claude
> « Donne-moi ce qui est demandé pour mon projet. » (consignes du livrable 1 en pièce jointe)

**Résultat :** génération de documents synthétiques : manuels techniques, procédures, fiches de sécurité, schémas, codes d'alarme et historiques de maintenance.

## P04 — 2026-10-31 — Claude
> « Chaque deux documents dans un PDF ; donne-moi aussi des photos. »

**Résultat :** 15 PDF regroupés et 16 images synthétiques, soit 31 fichiers.

## P05 — 2026-11-06 — ChatGPT
> « Je veux avoir plus de documentation, pas de photos, PDF avec texte. »

**Résultat :** enrichissement du corpus avec 22 PDF supplémentaires contenant principalement du texte.

## P06 — 2026-11-06 — ChatGPT
> « Non, tu me gardes 10 photos différentes. »

**Résultat final :** constitution d'un corpus de **47 documents**, comprenant :
- **35 PDF textuels**
- **2 PDF scannés** pour les tests OCR
- **10 images différentes** pour les tests multimodaux

Le corpus couvre les deux familles : système de freinage et entretien moteur.

**Équipe :** Safaa Hassani et Ayoub Lafdaigui.

---

## Analyse critique de l'usage de l'IA (½ page) — À COMPLÉTER PAR L'ÉQUIPE
Chaque membre relit les documents et note ici ce qu'il a réellement constaté. Points de contrôle suggérés :
- Les valeurs techniques (couples, épaisseurs, capacités) sont **fictives** : elles ne correspondent à aucun constructeur réel. Vérifier qu'elles restent identiques d'un document à l'autre.
- Codes OBD (P0xxx) et ABS (C0xxx, U0121) : vérifier la cohérence entre les codes, les manuels et les historiques.
- Vérifier les numéros de page de `elements_visuels` en ouvrant les PDF (numérotation continue sur le PDF fusionné).
- Contradictions **volontaires** : plaquettes v1/v2 et vidange v1/v2 ; l'historique INT-M-006 illustre l'usage d'une version obsolète.
- `procedures_v1_scannees` et `carnet_fiche_huile_scannes` sont des PDF-image (pas de texte extractible) : tester l'OCR.
- Les 16 images de tableau de bord sont **générées par script**, pas de vraies photos ; trois sont volontairement floues ou sombres pour tester le refus de répondre.
- Un PDF regroupe deux documents : le groupe d'accès retenu est le plus restrictif des deux (ex. `historique_freinage_note_service` : responsables uniquement).

## P07 — 06/11/2026 — ChatGPT
Créer 22 fiches documentaires synthétiques en français sur les deux familles freinage et entretien moteur, chacune en PDF texte avec tableau exploitable, traçabilité et avertissement de sécurité. Ne pas inventer de valeurs constructeur ni présenter les procédures comme certifiées.
